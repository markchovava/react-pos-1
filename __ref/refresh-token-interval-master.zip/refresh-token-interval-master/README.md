# Installation guide

git clone https://github.com/divanov11/refresh-token-interval

#Setup Backend
1. cd refresh-token-interval/backend
2. pip install -r requirements.txt
3. python manage.py createsuperuser
4.  python manage.py runserver

#Setup Frontend

1. cd refresh-token-interval/frontend
2. npm install
3. npm start
